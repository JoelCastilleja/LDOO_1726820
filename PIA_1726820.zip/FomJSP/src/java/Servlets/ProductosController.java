/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import Clases.Productos;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author hp
 */
@WebServlet(name = "ProductosController", urlPatterns = {"/ProductosController"})
public class ProductosController extends HttpServlet {

    Productos producto = new Productos();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            HttpSession session = request.getSession();
            /*if (list == null) {
                list = new ArrayList<String>();
                session.setAttribute("lista", list);
                request.getRequestDispatcher("BienVenido.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher("UsuarioDenegado.jsp").forward(request, response);
            }*/
            String opcion = request.getParameter("libros");
            Productos productos = new Productos();
            
            
            int numero = Integer.parseInt(opcion);

            if (1 == numero) {
                productos.setNombre("Cartas");
                productos.setPrecio("500");
                opcion = "entramos";
            } else if (2 == numero) {
                productos.setNombre("S.H Gold");
                productos.setPrecio("700");
            } else if (3 == numero) {
                productos.setNombre("Sherlock Holmes");
                productos.setPrecio("100");
            } else if (4 == numero) {
                productos.setNombre("S.H");
                productos.setPrecio("300");
            } else if (5 == numero) {
                productos.setNombre("Las Aventuras de S.H");
                productos.setPrecio("200");
            } else if (6 == numero) {
                productos.setNombre("Medico de cuerpo y alma");
                productos.setPrecio("150");
            } else {
                productos.setNombre("libro no encontrado");
                productos.setPrecio("=(");
            }

            // HttpSession sesssion = request.getSession(); 
            String productos1 = (String) session.getAttribute("lista");
            String guardado = productos1;
            request.setAttribute("Name", productos.getNombre());
            request.setAttribute("Precio", productos.getPrecio());
            request.setAttribute("lis", productos1);
            session.setAttribute("lista", productos.toString());
            if (productos1 == null) {
                productos1 = new String();
                // session.setAttribute("lista", productos1);
                guardado += productos1;
                request.getRequestDispatcher("BienVenido.jsp").forward(request, response);

            } else {

                //request.getRequestDispatcher("UsuarioDenegado.jsp").forward(request, response);
            }

            request.getRequestDispatcher("BienVenido.jsp").forward(request, response);

        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
