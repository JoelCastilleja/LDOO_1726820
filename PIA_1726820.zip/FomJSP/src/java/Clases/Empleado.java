package Clases;

public class Empleado extends Conexion{
    
    private static Empleado empleado; 
    private String nombre = null;
    private String sexo = null;
    private String fechaNacim = null;
    private String email = null;
    private String password = null;
    
    public Empleado(){
        
    }
    
  
    
}
