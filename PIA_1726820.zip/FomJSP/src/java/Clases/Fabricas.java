
package Clases;

public class Fabricas {
    String tipo; 
    public Fabricas (String motor){
        tipo = motor; 
    }
    
    public Conexion CreaConexion(){
        if(tipo.equals("empleado")){
            return new Empleado();
            
        }
        else{
            return null; 
        }
    }
        
        
    }